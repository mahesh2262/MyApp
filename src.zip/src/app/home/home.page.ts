import { Component, OnInit, Sanitizer } from '@angular/core';
import { DomSanitizer, SafeResourceUrl } from '@angular/platform-browser';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { StorageService } from '../Services/storage.service';

@Component({
  selector: 'app-home',
  templateUrl: 'home.page.html',
  styleUrls: ['home.page.scss'],
})
export class HomePage implements OnInit {

  imageUrl: string | undefined;
  photo: SafeResourceUrl | any;
  modalPPhoto: SafeResourceUrl | any;
  picName: string | undefined;
  selectedFile: File | undefined;

  constructor(
    private _sanitizer: DomSanitizer,
    private _storage: StorageService
  ) {
  }

  async ngOnInit() {
    console.log(await this._storage.get('login'));
    // await this._storage.set('username', 'IonicUser');
    // const username = await this._storage.get('username');
    // console.log('Username:', username);
  }

  async clickPicture() {
    const image = await Camera.getPhoto({
      resultType: CameraResultType.Uri,
      source: CameraSource.Camera,
      quality: 90,
    });
    this.imageUrl = image.webPath;

    if (image && image.webPath) {

      let blob = await fetch(image.webPath).then((r) => r.blob());
      let filename = 'cam_' + 'kkt' + ".jpg";
      // this.picName = filename;
      this.selectedFile = new File([blob], filename, { type: blob.type, lastModified: Date.now() });
      this.photo = this._sanitizer.bypassSecurityTrustUrl(URL.createObjectURL(this.selectedFile));
      await this._storage.set('pic', filename);
    }
  }

  async getPhoto(){
    this.picName = await this._storage.get('pic');
  }
}
